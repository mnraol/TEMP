package esb;

@SuppressWarnings("serial")
public class ExceptionNotification extends Exception {
	public ExceptionNotification(String message){
		super(message);
	}
	public ExceptionNotification(Throwable cause){
		super(cause);
	}
	public ExceptionNotification(String message,Throwable cause){
		super(message, cause);
	}
	public ExceptionNotification(){
		super();
	}
	public static void throwException(String message) throws Exception {
		throw new esb.ExceptionNotification(message);
	}
	public static void throwException(Throwable cause) throws Exception {
		throw new esb.ExceptionNotification(cause);
	}
}
