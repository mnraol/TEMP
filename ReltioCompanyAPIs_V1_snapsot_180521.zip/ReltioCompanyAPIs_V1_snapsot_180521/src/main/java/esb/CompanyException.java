package esb;

@SuppressWarnings("serial")
public class CompanyException extends Exception {
	public CompanyException(String message){
		super(message);
	}
	public CompanyException(Throwable cause){
		super(cause);
	}
	public CompanyException(String message,Throwable cause){
		super(message, cause);
	}
	public CompanyException(){
		super();
	}
	public static void throwException(String message) throws Exception {
		throw new esb.CompanyException(message);
	}
	public static void throwException(Throwable cause) throws Exception {
		throw new esb.CompanyException(cause);
	}
}
